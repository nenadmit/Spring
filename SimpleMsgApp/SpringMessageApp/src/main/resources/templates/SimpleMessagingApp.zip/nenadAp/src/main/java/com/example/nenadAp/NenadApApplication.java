package com.example.nenadAp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NenadApApplication {

	public static void main(String[] args) {
		SpringApplication.run(NenadApApplication.class, args);
	}

}
