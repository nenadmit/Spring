package com.example.nenadAp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NenadApApplicationTests {

	@Test
	void contextLoads() {
	}

}
