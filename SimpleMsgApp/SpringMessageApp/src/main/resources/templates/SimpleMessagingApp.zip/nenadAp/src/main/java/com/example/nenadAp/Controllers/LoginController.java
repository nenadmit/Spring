package com.example.nenadAp.Controllers;

import com.example.nenadAp.UserDetails.PrincipalUser;
import com.example.nenadAp.model.User;
import com.example.nenadAp.model.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import javax.validation.constraints.Null;
import java.util.Arrays;
import java.util.Optional;


@Controller
public class LoginController {

    public User user;
    public HttpSession session;
    @Autowired
    public UserRepository userRepo;

    @GetMapping(path="/login")
    public String getIndex(){

        return "login";

    }


    @PostMapping(path="/sucess")
    public String sucess(HttpSession session){

        PrincipalUser loggedUser = (PrincipalUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        session.setAttribute("username",loggedUser.getUsername());
        session.setAttribute("name",loggedUser.getName());

        return "redirect:/inbox";
    }





    }


