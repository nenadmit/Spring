package com.example.nenadAp.Controllers;

import com.example.nenadAp.UserDetails.PrincipalUser;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TestController {

    private boolean n;

    @GetMapping(path="/profile")
    public String getProfile(Model model){

        model.addAttribute("check",n);

        return "profile";
    }
    @PostMapping(path="/profile")
    public String asd(){
        n = !n;
       return "redirect:/profile";
    }

    @GetMapping(path="/getuser")
    @ResponseBody
    public PrincipalUser getUser(){
        PrincipalUser loggedUser = (PrincipalUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return loggedUser;
    }


}
