package com.example.nenadAp.Controllers;

import com.example.nenadAp.model.Messages;
import com.example.nenadAp.model.MsgRepository;
import com.example.nenadAp.model.User;
import com.example.nenadAp.model.UserRepository;
import org.aspectj.bridge.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.*;


@Controller
public class InboxController {



    private Messages message;
    @Autowired
    private MsgRepository msgRepo;
    @Autowired
    private UserRepository userRepo;

    @GetMapping(path="/inbox")
    public String getInbox(Model model, HttpSession session){

        message = new Messages();
        model.addAttribute("message",message);
        model.addAttribute("user",session.getAttribute("username"));

        return "inbox";
    }
    @PostMapping(path="/inbox")
    public String sendMessage(@ModelAttribute("message") Messages message, Model model,
                              BindingResult result, HttpSession session){

        User receiver = userRepo.findByUsername(message.getReceiver());
        if(receiver!=null){
            String s = (String) session.getAttribute("username");

            message = new Messages(message.getTitle(), s ,message.getReceiver(),message.getMsgBody());
            msgRepo.save(message);

            System.out.println(session.getAttribute("username"));

            model.addAttribute("sucess","Message has been sent!");
            return "inbox";

        }
        String s = "User + " + message.getReceiver() + " doesn't exist in a database!";
        model.addAttribute("sucess",s);

        return "inbox";
    }
    @GetMapping(path="/received")
    public String sendRecievedMessages(Model model, HttpSession session){


        ArrayList<Messages>arr2 = new ArrayList<>();
        String sender = (String) session.getAttribute("username");
        Iterable<Messages> arr = msgRepo.findAllBySender(sender);

        arr.forEach(messages -> arr2.add(messages));
        model.addAttribute("arr2",reverseArray(arr2));

        return "received";
    }

    @GetMapping(path="/sent")
    public String sendSentMessages(Model model, HttpSession session){

        ArrayList<Messages>arr2 = new ArrayList<>();
        String receiver = (String) session.getAttribute("username");
        Iterable<Messages> arr = msgRepo.findAllByReceiver(receiver);




        arr.forEach(messages -> arr2.add(messages));
        model.addAttribute("arr2",reverseArray(arr2));

        return "sent";
    }
    @GetMapping(path="/delete")
    public String deleteMsg(@RequestParam int id){
        msgRepo.deleteById(id);
        return "redirect:/sent";
    }




    //* Reversing an ArrayList of messages since i couldn't get LinkedList to show on thymeleaf template with th:forEach element
    public ArrayList<Messages> reverseArray(ArrayList<Messages> arr){

        Stack<Messages> stack = new Stack<>();
        arr.forEach(msg->stack.push(msg));
        ArrayList<Messages> reversedArr = new ArrayList<>();
        for ( var a:arr){
            reversedArr.add(stack.pop());

        }


        return reversedArr;
    }



}
